package practica.Servicios;

public class EquipoServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7247127928074734840L;

	public EquipoServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EquipoServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EquipoServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EquipoServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EquipoServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
