package practica.Modelo;

public class Menu {

	public void primerMenu(Integer numero) {
		System.out.println("----------------------------------------------------------");
		System.out.println("Elige una de estas opciones:\n\t (1) Ver todos los equipos registrados\n\t (2) Crear un nuevo equipo\n\t (3) Consulta un equipo por su codigo\n\t (0) Salir");
		System.out.println("----------------------------------------------------------");
		
	}
	
}
