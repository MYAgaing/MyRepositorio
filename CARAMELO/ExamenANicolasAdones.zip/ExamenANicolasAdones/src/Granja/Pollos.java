package Granja;

public class Pollos extends Animales{
	

	
	
	public Pollos(Integer num_registro) {
		super(num_registro);
		this.tipo = true;
	}
	
}
